import { Component, OnInit } from '@angular/core';
import { Router } from  '@angular/router';
import { AuthService } from  '../auth.service';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  isSubmitted  =  false;
  userEmail: string="";
  userPassword: string="";
  loginError:number = 0;

  constructor(private authService: AuthService, private router: Router, private httpClient: HttpClient) { }
  ngOnInit() {  }

  signIn(){
    var login = 0;
    this.isSubmitted = true;
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
        var userEmail = this.userEmail;
        var userPassword = this.userPassword;
        var authService = this.authService;
        var router = this.router;
        var loginError = this.loginError;
        data.users.forEach(function(value){
          if(value.loginId == userEmail && value.password == userPassword && value.role == "mac"){
            authService.signIn(userEmail);
            router.navigateByUrl('/mac');
            loginError = 0;
            login = 1;
          }
      });
    });
    if(!login){
      this.loginError = 1;
    }
  } 
}