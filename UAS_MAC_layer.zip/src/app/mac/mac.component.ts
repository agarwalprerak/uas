import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { HttpClient, HttpErrorResponse  } from "@angular/common/http";

@Component({
  selector: 'app-mac',
  templateUrl: './mac.component.html',
  styleUrls: ['./mac.component.css']
})
export class MacComponent implements OnInit {

  wholeData: any[];
  loginUserName: string;
  constructor(private authService: AuthService, private router: Router,private httpClient: HttpClient) {
    this.loginUserName = this.authService.getUserName();
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.wholeData = data;
    });
    this.router.navigate(["/mac/viewCourses"]);
   }

  ngOnInit(): void {

  }

  logout(){
    this.authService.logout();
    this.router.navigateByUrl('/auth');
  }

}
