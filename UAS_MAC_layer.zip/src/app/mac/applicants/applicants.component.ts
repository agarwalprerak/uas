import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-applicants',
  templateUrl: './applicants.component.html',
  styleUrls: ['./applicants.component.css']
})
export class ApplicantsComponent implements OnInit {

  targetCourse = 0;
  applicants:any[]=[];

  constructor(private httpClient: HttpClient,private router: ActivatedRoute) {
    if(this.router.snapshot.queryParamMap.has('id')){
      this.targetCourse = parseInt(this.router.snapshot.queryParamMap.get('id'));
    }
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.applicants = data.applicant;
    });
  }

  ngOnInit(): void {

  }

  formatDate(date){
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [day, month, year].join('-');
  }

  scheduledInterview(indexId){
    var date=((document.getElementById("interviewDate_"+indexId) as HTMLInputElement).value);
    var finalDate = this.formatDate(date);
    this.applicants[indexId].dateOfInterview = finalDate;
  }

  updateStatus(status,indexId){
    this.applicants[indexId].status = status;
  }
}
