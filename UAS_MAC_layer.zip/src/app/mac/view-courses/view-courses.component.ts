import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-view-courses',
  templateUrl: './view-courses.component.html',
  styleUrls: ['./view-courses.component.css']
})
export class ViewCoursesComponent implements OnInit {

  courses:any[]=[];
  constructor(private httpClient: HttpClient) {
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.courses = data.programsOffered;
    });
  }

  ngOnInit(): void {

  }
}
