import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-schedule',
  templateUrl: './view-schedule.component.html',
  styleUrls: ['./view-schedule.component.css']
})
export class ViewScheduleComponent implements OnInit {

  targetId:string;
  schedules:any[]=[];
  constructor(private httpClient: HttpClient,private router: ActivatedRoute) {
    this.router.params.subscribe( params => this.targetId = params['id']);
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.schedules = data.programsScheduled;
    });
  }

  ngOnInit(): void {
  }

}
