import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  public signIn(userEmail: string){
    localStorage.setItem('ACCESS_TOKEN', userEmail);
  }
  public isLoggedIn(){
    return localStorage.getItem('ACCESS_TOKEN') !== null;
  }
  public logout(){
    localStorage.removeItem('ACCESS_TOKEN');
  }

  public getUserName(){
    return localStorage.getItem('ACCESS_TOKEN');
  }
}
